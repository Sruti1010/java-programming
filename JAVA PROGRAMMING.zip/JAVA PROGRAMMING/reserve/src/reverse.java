import java.util.Scanner;
public class reverse {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number to reverse: ");
        int n = scanner.nextInt();
        int reverse = 0;
        while (n!=0)
        {
            int d = n % 10;
            reverse = reverse * 10 + d;
            n /= 10;
        }
        System.out.println("Reversed number: " + reverse);
        scanner.close();
    }
}
