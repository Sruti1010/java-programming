import java.util.Scanner;
public class Arm {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number for an Armstrong number: ");
        int number = scanner.nextInt();
        int original = number;
        int result = 0;
        int Digits = String.valueOf(number).length();
        while (original != 0) {
            int digit = original % 10;
            result += Math.pow(digit,Digits);
            original /= 10;
        }
        if (result == number) {
            System.out.println(number + " is an Armstrong number.");
        } else {
            System.out.println(number + " is not an Armstrong number.");
        }

        scanner.close();
    }
}
