import java.util.Scanner;
public class ASCII {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an alphabet: ");
        char inputChar = scanner.next().charAt(0);
        if (Character.isLetter(inputChar)) {
            int asciiValue = (int) inputChar;
            System.out.println("The ASCII value of '" + inputChar + "' is: " + asciiValue);
        }
        else
        {
            System.out.println("Invalid input! Please enter a valid alphabet.");
        }
        scanner.close();
    }
}