import java.util.Scanner;

public class CtoF {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter temperature in Celsius: ");
        double celsius = scanner.nextDouble();
        // Convert Celsius to Fahrenheit using the formula: (C * 9/5) + 32
        double fahrenheit = (celsius * 9/5) + 32;
        System.out.printf("%.2f degrees Celsius is equal to %.2f degrees Fahrenheit.%n", celsius, fahrenheit);
        scanner.close();
    }
}