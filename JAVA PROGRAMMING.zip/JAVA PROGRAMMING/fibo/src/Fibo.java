import java.util.Scanner;
public class Fibo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Number for  Fibonacci series: ");
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Please enter a positive integer.");
        }
        else
        {
            System.out.println("Fibonacci Series up to " + n + " terms:");
            int a = 0, b = 1;
            for (int i = 1; i <= n; i++) {
                System.out.print(a + " ");
                int c = a + b;
               a = b;
                b = c;
            }
        }
        scanner.close();
    }
}
