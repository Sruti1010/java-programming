import java.util.Scanner;

public class Neon {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number to check if it is a Neon number: ");
        int n = scanner.nextInt();
        int s = n * n;
        int sum = 0;
        while (s > 0) {
            sum += s % 10;
            s/= 10;
        }
        if (sum == n) {
            System.out.println(n + " is a Neon number.");
        } else {
            System.out.println(n + " is not a Neon number.");
        }

        scanner.close();
    }
}
